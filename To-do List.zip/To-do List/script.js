function addTodo() {
    const inputElement = document.getElementById('todo-input');
    const inputValue = inputElement.value.trim();

    if (inputValue !== '') {
        const todoList = document.getElementById('todo-list');

        const li = document.createElement('li');
        li.className = 'todo-item';
        li.innerHTML = `
            <span>${inputValue}</span>
            <button onclick="removeTodo(this)">Remove</button>
        `;

        todoList.appendChild(li);
        inputElement.value = '';
    }
}

function removeTodo(button) {
    const todoItem = button.parentNode;
    const todoList = document.getElementById('todo-list');
    todoList.removeChild(todoItem);
}
